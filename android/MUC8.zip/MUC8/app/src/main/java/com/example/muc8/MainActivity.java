/*package com.example.muc8;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private MqttClient mqttClient;
    private TextView messageTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        messageTextView = findViewById(R.id.messageTextView);
        connectToMqttBroker();
    }

    private void connectToMqttBroker() {
        try {
            mqttClient = new MqttClient("tcp://192.168.0.3:1883", "AndroidClient", new MemoryPersistence());
            MqttConnectOptions options = new MqttConnectOptions();
            options.setCleanSession(true);

            Log.d(TAG, "Connecting to MQTT broker...");
            mqttClient.connect();

        } catch (MqttException e) {
            e.printStackTrace();
            String errorMessage = "Exception while connecting to MQTT broker: " + e.getMessage();
            showToast(errorMessage);
            Log.e(TAG, errorMessage, e);
        }
    }

    private void subscribeToTopic(String topic) {
        try {
            Log.d(TAG, "Subscribing to topic: " + topic);
            mqttClient.subscribe(topic);
        } catch (MqttException e) {
            e.printStackTrace();
            String errorMessage = "Exception while subscribing to topic: " + e.getMessage();
            showToast(errorMessage);
            Log.e(TAG, errorMessage, e);
        }
    }

    private void showToast(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateTextView(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                messageTextView.setText(message);
            }
        });
    }
}
*/


package com.example.muc8;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private MqttClient mqttClient;
    private TextView messageTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        System.out.println("___________________________________________");
        messageTextView = findViewById(R.id.messageTextView);
        connectToMqttBroker();
    }

    private void connectToMqttBroker() {
        try {
            System.out.println("++++++++++++++++1++++++++++++++++++");
            mqttClient = new MqttClient("tcp://127.0.0.1:1883", "AndroidClient", new MemoryPersistence());
            MqttConnectOptions options = new MqttConnectOptions();
            options.setCleanSession(true);
            System.out.println("++++++++++++++++++2++++++++++++++++");
            Log.i(TAG, "Connecting to MQTT broker...");
            System.out.println("+++++++++++++++++3++++++++++++++++++");
            mqttClient.connect(options);

            // Set the callback to handle incoming messages and connection loss
            mqttClient.setCallback(new MqttCallback() {
                @Override
                public void connectionLost(Throwable cause) {
                    showToast("Connection lost");
                    Log.e(TAG, "Connection lost", cause);
                }

                @Override
                public void messageArrived(String topic, MqttMessage message) throws Exception {
                    // Handle incoming messages
                    String payload = new String(message.getPayload());
                    updateTextView("Received message: " + payload);
                    Log.d(TAG, "Received message: " + payload);
                }

                @Override
                public void deliveryComplete(IMqttDeliveryToken token) {
                    // Handle delivery complete
                    Log.d(TAG, "Delivery complete");
                }
            });

            showToast("Connected to MQTT broker");
            Log.d(TAG, "Connected to MQTT broker");

            // Subscribe to the topic after successful connection
            subscribeToTopic("random/number");

        } catch (MqttException e) {
            e.printStackTrace();
            String errorMessage = "Exception while connecting to MQTT broker: " + e.getMessage();
            showToast(errorMessage);
            Log.e(TAG, errorMessage, e);
        }
    }

    private void subscribeToTopic(String topic) {
        try {
            Log.d(TAG, "Subscribing to topic: " + topic);
            mqttClient.subscribe(topic);
        } catch (MqttException e) {
            e.printStackTrace();
            String errorMessage = "Exception while subscribing to topic: " + e.getMessage();
            showToast(errorMessage);
            Log.e(TAG, errorMessage, e);
        }
    }

    private void showToast(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateTextView(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                messageTextView.setText(message);
            }
        });
    }
}


